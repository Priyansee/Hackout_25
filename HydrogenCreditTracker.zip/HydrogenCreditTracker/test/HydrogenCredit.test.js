// File: test/HydrogenCredit.test.js
const HydrogenCredit = artifacts.require("HydrogenCredit");

const { expectRevert, expectEvent } = require('@openzeppelin/test-helpers');
const { assert } = require('chai');

contract('HydrogenCredit', (accounts) => {
  const [admin, certifier, producer, buyer] = accounts;

  beforeEach(async () => {
    this.token = await HydrogenCredit.new("GreenHydrogenCredit", "GHC", { from: admin });
    await this.token.addCertifier(certifier, { from: admin });
  });

  it('certifier can issue and mint certificate', async () => {
    const certId = web3.utils.soliditySha3({ t: 'string', v: 'cert-001' });
    const amount = web3.utils.toBN(1000);

    const tx = await this.token.issueAndMintCertificate(certId, producer, amount, { from: certifier });
    expectEvent(tx, 'CertificateIssued', { certificateId: certId });
    expectEvent(tx, 'CertificateMinted', { certificateId: certId });

    const balance = await this.token.balanceOf(producer);
    assert(balance.eq(amount), 'producer should receive minted credits');
  });

  it('prevents double minting of same certificate', async () => {
    const certId = web3.utils.soliditySha3({ t: 'string', v: 'cert-002' });
    const amount = web3.utils.toBN(500);

    await this.token.issueAndMintCertificate(certId, producer, amount, { from: certifier });
    await expectRevert(
      this.token.issueAndMintCertificate(certId, producer, amount, { from: certifier }),
      'Certificate already minted'
    );
  });

  it('producer can transfer and retire credits', async () => {
    const certId = web3.utils.soliditySha3({ t: 'string', v: 'cert-003' });
    const amount = web3.utils.toBN(200);

    await this.token.issueAndMintCertificate(certId, producer, amount, { from: certifier });

    await this.token.transfer(buyer, 50, { from: producer });
    let buyerBal = await this.token.balanceOf(buyer);
    assert(buyerBal.toNumber() === 50, 'buyer should have 50 tokens');

    const retireTx = await this.token.retire(20, "Used for green ammonia", { from: buyer });
    expectEvent(retireTx, 'CreditsRetired', { holder: buyer });

    const buyerBalAfter = await this.token.balanceOf(buyer);
    assert(buyerBalAfter.toNumber() === 30, 'buyer should have 30 tokens after retirement');

    const retired = await this.token.retiredOf(buyer);
    assert(retired.toNumber() === 20, 'retired balance should be 20');
  });

  it('only certifier can issue certificates', async () => {
    const certId = web3.utils.soliditySha3({ t: 'string', v: 'cert-004' });
    await expectRevert(
      this.token.issueAndMintCertificate(certId, producer, 100, { from: admin }),
      'AccessControl: account ' + admin.toLowerCase() + ' is missing role ' + web3.utils.keccak256('CERTIFIER_ROLE')
    );
  });
});
